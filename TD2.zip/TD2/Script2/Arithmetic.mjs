export function add(a,b){
    console.log(a + b);
}

export function multiply(a,b){
    console.log(a * b);
}

export function minus(a,b){
    console.log(a - b);
}

export function divide(a,b){
    console.log(a / b);
}