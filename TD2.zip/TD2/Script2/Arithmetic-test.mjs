import * as Arithmetic from './Arithmetic.mjs'

Arithmetic.add(1,2)
Arithmetic.minus(1,2)
Arithmetic.multiply(1,2)
Arithmetic.divide(1,2)