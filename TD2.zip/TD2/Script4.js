
var argtab = process.argv.slice(2)
var taille = argtab.length;
console.log(`number of args: ${taille} each arg is ${argtab}`)

